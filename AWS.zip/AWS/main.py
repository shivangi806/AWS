


import numpy as np
import cv2
from tensorflow.keras.applications import VGG16
from tensorflow.keras.applications.vgg16 import preprocess_input, decode_predictions
from tensorflow.keras.preprocessing.image import img_to_array, load_img



model = VGG16(weights='imagenet')


def load_and_preprocess_image(image_path):
    # Load the image with the target size of 224x224 pixels
    image = load_img(image_path, target_size=(224, 224))
    # Convert the image to an array
    image = img_to_array(image)
    # Expand the dimensions of the image to fit the model's input requirements
    image = np.expand_dims(image, axis=0)
    # Preprocess the image
    image = preprocess_input(image)
    return image


def predict_dog_breed(image_path):
    # Load and preprocess the image
    image = load_and_preprocess_image(image_path)
    # Make predictions using the model
    predictions = model.predict(image)
    # Decode the predictions
    decoded_predictions = decode_predictions(predictions, top=3)[0]
    return decoded_predictions


image_path = 'sample1.png'
predictions = predict_dog_breed(image_path)

print("Predictions:")
for i, (imagenet_id, label, score) in enumerate(predictions):
    print(f"{i+1}. {label}: {score*100:.2f}%")


